/* ═══════════════════════════════════════════════════════════════
   SUPERSUITE SSV26.1  —  script.js
   Pure vanilla JS, no frameworks, no build step
   ═══════════════════════════════════════════════════════════════ */

// ── Constants ────────────────────────────────────────────────────
const ACCESS_CODES = { SS26:'free', SSBASIC:'basic', SSPRO:'pro', SSAGENCY:'agency' };
const TIER_LIMITS  = {
  free:   { projects:1,  blocks:6,   label:'Free',   desc:'1 project · 6 blocks' },
  basic:  { projects:3,  blocks:20,  label:'Basic',  desc:'3 projects · 20 blocks' },
  pro:    { projects:10, blocks:100, label:'Pro',    desc:'10 projects · 100 blocks' },
  agency: { projects:99, blocks:999, label:'Agency', desc:'Unlimited' },
};
const TIER_CLASS = { free:'tp-free', basic:'tp-basic', pro:'tp-pro', agency:'tp-agency' };
const NAV_TIER_CLASS = { free:'tp-free', basic:'tp-basic', pro:'tp-pro', agency:'tp-agency' };
const DEVICE_WIDTHS = { desktop:1200, tablet:768, mobile:390 };
const BLOCK_DEFS = [
  { type:'nav',          label:'Navigation',  desc:'Sticky nav + CTA',         preview:'■ Logo  Links ···  [CTA]' },
  { type:'hero',         label:'Hero',        desc:'Headline · sub · CTAs',    preview:'BIG HEADING / Subtext / [CTA]' },
  { type:'features',     label:'Features',    desc:'Feature cards grid',       preview:'█  │  █  │  █   grid' },
  { type:'pricing',      label:'Pricing',     desc:'Pricing tiers',            preview:'$0  $19  $49  $149' },
  { type:'testimonials', label:'Testimonials',desc:'Quote cards',              preview:'★★★★★  Quote cards' },
  { type:'cta',          label:'CTA',         desc:'Call to action banner',    preview:'[ Call  to  Action  Banner ]' },
  { type:'gallery',      label:'Gallery',     desc:'Image grid',               preview:'░░ │ ░░ │ ░░  Gallery' },
  { type:'widget',       label:'Widget',      desc:'Countdown / embed',        preview:'00 : 00 : 00 : 00' },
  { type:'footer',       label:'Footer',      desc:'Site footer',              preview:'Logo  Links  Social  ©' },
  { type:'leadform',     label:'Lead Form',   desc:'Contact form + webhook',   preview:'[ Fields ]  [ Submit ]' },
];
const THEMES = [
  { id:'liquid-glass', name:'Liquid Glass', desc:'Dark glassmorphism · orange & purple',
    colors:['#0f0f13','#ff6b35','#8b5cf6','#3b82f6'],
    css:`
      :root{--bg:#0f0f13;--bg2:#16161e;--bg3:#1e1e28;--bg4:#252530;--text:#f0f0fa;--text2:#9090b0;--text3:#5a5a80;--accent:#ff6b35;--accent2:#8b5cf6;--accent3:#3b82f6;--border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);--r:12px;--r-lg:20px;--r-sm:6px;--shadow:0 8px 32px rgba(0,0,0,.4)}
      body{background:var(--bg);color:var(--text);font-family:var(--fb)}
      h1,h2,h3,h4,h5,h6{font-family:var(--fh);font-weight:800;letter-spacing:-.03em}
      .ss-btn-p{background:linear-gradient(135deg,#ff6b35,#ff3d00);color:#fff;border:none;border-radius:var(--r);padding:12px 28px;font-weight:700;cursor:pointer;box-shadow:0 8px 24px rgba(255,107,53,.35);transition:all .2s;font-family:var(--fb)}
      .ss-btn-p:hover{transform:translateY(-2px);box-shadow:0 12px 36px rgba(255,107,53,.5)}
      .ss-btn-s{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:var(--text);border-radius:var(--r);padding:12px 24px;font-weight:600;cursor:pointer;font-family:var(--fb);transition:all .2s}
      .ss-btn-s:hover{background:rgba(255,255,255,.1)}
      .ss-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:28px;transition:all .2s}
      .ss-card:hover{border-color:rgba(255,107,53,.3);transform:translateY(-2px)}
      .ss-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(255,107,53,.1);border:1px solid rgba(255,107,53,.2);border-radius:50px;padding:6px 16px;font-size:13px;font-weight:600;color:#ff6b35}
      .ss-kicker{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:var(--accent);margin-bottom:12px}
      .ss-gtext{background:linear-gradient(135deg,#ff6b35,#ff3d00,#a78bfa);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
      .ss-input{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-sm);padding:12px 16px;color:var(--text);font-family:var(--fb);width:100%;outline:none;transition:border .2s}
      .ss-input:focus{border-color:var(--accent)}
      .ss-glass{background:rgba(255,255,255,.04);backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-lg)}
    `},
  { id:'classy-bold', name:'Classy Bold', desc:'Light · serif · gold accents',
    colors:['#fafaf8','#1a1a1a','#c9a94a','#2d5a27'],
    css:`
      :root{--bg:#fafaf8;--bg2:#f0ede8;--bg3:#e8e4dd;--bg4:#ddd8cf;--text:#1a1a1a;--text2:#5a5a5a;--text3:#8a8a8a;--accent:#c9a94a;--accent2:#2d5a27;--accent3:#8b2635;--border:rgba(0,0,0,.1);--border2:rgba(0,0,0,.18);--r:4px;--r-lg:8px;--r-sm:2px;--shadow:0 4px 20px rgba(0,0,0,.1)}
      body{background:var(--bg);color:var(--text);font-family:var(--fb)}
      h1,h2,h3,h4,h5,h6{font-family:'Playfair Display','Georgia',serif;font-weight:700;letter-spacing:-.02em;color:var(--text)}
      .ss-btn-p{background:#1a1a1a;color:#fafaf8;border:none;border-radius:var(--r);padding:12px 28px;font-weight:600;cursor:pointer;transition:all .2s;letter-spacing:.03em;font-family:var(--fb)}
      .ss-btn-p:hover{background:#333}
      .ss-btn-s{background:transparent;border:2px solid #1a1a1a;color:#1a1a1a;border-radius:var(--r);padding:10px 24px;font-weight:600;cursor:pointer;font-family:var(--fb);transition:all .2s}
      .ss-btn-s:hover{background:#1a1a1a;color:#fafaf8}
      .ss-card{background:#fff;border:1px solid rgba(0,0,0,.08);border-radius:var(--r-lg);padding:28px;box-shadow:0 2px 12px rgba(0,0,0,.06)}
      .ss-badge{display:inline-flex;background:#f0ede8;border:1px solid #ddd8cf;color:#5a5a5a;padding:5px 14px;border-radius:3px;font-size:12px;font-weight:600;letter-spacing:.05em}
      .ss-kicker{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--accent);margin-bottom:12px}
      .ss-gtext{color:var(--accent);-webkit-text-fill-color:initial}
      .ss-input{background:#fff;border:1px solid rgba(0,0,0,.15);border-radius:var(--r-sm);padding:12px 16px;color:var(--text);font-family:var(--fb);width:100%;outline:none}
      .ss-input:focus{border-color:var(--accent)}
      .ss-glass{background:rgba(255,255,255,.85);backdrop-filter:blur(8px);border:1px solid rgba(0,0,0,.1);border-radius:var(--r-lg)}
    `},
  { id:'neon-dark', name:'Neon Dark', desc:'Electric neon glow · deep dark',
    colors:['#050508','#00f5ff','#ff00e5','#39ff14'],
    css:`
      :root{--bg:#050508;--bg2:#0a0a10;--bg3:#0e0e18;--bg4:#14141e;--text:#e8e8ff;--text2:#6868a8;--text3:#3a3a78;--accent:#00f5ff;--accent2:#ff00e5;--accent3:#39ff14;--border:rgba(0,245,255,.1);--border2:rgba(0,245,255,.2);--r:8px;--r-lg:14px;--r-sm:4px;--shadow:0 0 40px rgba(0,245,255,.1);--glow:0 0 20px rgba(0,245,255,.4),0 0 60px rgba(0,245,255,.1)}
      body{background:var(--bg);color:var(--text);font-family:var(--fb)}
      h1,h2,h3,h4,h5,h6{font-family:var(--fh);font-weight:800;letter-spacing:-.02em}
      .ss-btn-p{background:linear-gradient(135deg,#00f5ff,#0080ff);color:#050508;border:none;border-radius:var(--r);padding:12px 28px;font-weight:800;cursor:pointer;box-shadow:var(--glow);transition:all .2s;font-family:var(--fb)}
      .ss-btn-p:hover{transform:translateY(-2px);box-shadow:0 0 40px rgba(0,245,255,.6)}
      .ss-btn-s{background:transparent;border:1px solid rgba(0,245,255,.3);color:var(--accent);border-radius:var(--r);padding:12px 24px;font-weight:600;cursor:pointer;font-family:var(--fb);transition:all .2s}
      .ss-btn-s:hover{border-color:var(--accent);box-shadow:var(--glow)}
      .ss-card{background:rgba(0,245,255,.03);border:1px solid rgba(0,245,255,.12);border-radius:var(--r-lg);padding:28px;transition:all .2s}
      .ss-card:hover{border-color:var(--accent);box-shadow:var(--glow)}
      .ss-badge{display:inline-flex;background:rgba(0,245,255,.08);border:1px solid rgba(0,245,255,.2);color:var(--accent);padding:5px 16px;border-radius:50px;font-size:12px;font-weight:700;letter-spacing:.05em}
      .ss-kicker{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:var(--accent);margin-bottom:12px;text-shadow:var(--glow)}
      .ss-gtext{background:linear-gradient(135deg,#00f5ff,#ff00e5);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
      .ss-input{background:rgba(0,245,255,.03);border:1px solid rgba(0,245,255,.15);border-radius:var(--r-sm);padding:12px 16px;color:var(--text);font-family:var(--fb);width:100%;outline:none}
      .ss-input:focus{border-color:var(--accent);box-shadow:0 0 8px rgba(0,245,255,.3)}
      .ss-glass{background:rgba(0,245,255,.03);border:1px solid rgba(0,245,255,.1);border-radius:var(--r-lg)}
    `},
  { id:'brutalist', name:'Brutalist', desc:'Raw · bold · high-contrast',
    colors:['#ffffff','#000000','#ffff00','#ff0000'],
    css:`
      :root{--bg:#fff;--bg2:#f0f0f0;--bg3:#e0e0e0;--bg4:#ccc;--text:#000;--text2:#444;--text3:#888;--accent:#ffff00;--accent2:#ff0000;--accent3:#0000ff;--border:#000;--border2:#333;--r:0px;--r-lg:0px;--r-sm:0px;--shadow:4px 4px 0 #000}
      body{background:var(--bg);color:var(--text);font-family:var(--fb)}
      h1,h2,h3,h4,h5,h6{font-family:var(--fh);font-weight:900;text-transform:uppercase;letter-spacing:-.02em}
      .ss-btn-p{background:#ffff00;color:#000;border:3px solid #000;padding:12px 28px;font-weight:900;font-size:14px;cursor:pointer;box-shadow:4px 4px 0 #000;transition:all .1s;text-transform:uppercase;letter-spacing:.05em;font-family:var(--fb)}
      .ss-btn-p:hover{transform:translate(-2px,-2px);box-shadow:6px 6px 0 #000}
      .ss-btn-p:active{transform:translate(2px,2px);box-shadow:2px 2px 0 #000}
      .ss-btn-s{background:#fff;border:3px solid #000;color:#000;padding:12px 24px;font-weight:700;cursor:pointer;box-shadow:4px 4px 0 #000;transition:all .1s;text-transform:uppercase;font-family:var(--fb)}
      .ss-btn-s:hover{transform:translate(-2px,-2px);box-shadow:6px 6px 0 #000}
      .ss-card{background:#fff;border:3px solid #000;padding:28px;box-shadow:var(--shadow);transition:all .1s}
      .ss-card:hover{transform:translate(-2px,-2px);box-shadow:6px 6px 0 #000}
      .ss-badge{display:inline-flex;background:#ffff00;border:2px solid #000;color:#000;padding:4px 12px;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.1em}
      .ss-kicker{font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:2px;color:#000;margin-bottom:12px;border-bottom:3px solid #000;padding-bottom:6px;display:inline-block}
      .ss-gtext{-webkit-text-fill-color:initial;color:#000;text-decoration:underline;text-decoration-color:#ffff00;text-decoration-thickness:6px}
      .ss-input{background:#fff;border:3px solid #000;padding:12px 16px;color:#000;font-family:var(--fb);width:100%;outline:none}
      .ss-input:focus{border-color:#ffff00;outline:3px solid #000}
      .ss-glass{background:#fff;border:3px solid #000}
    `},
  { id:'minimal-zen', name:'Minimal Zen', desc:'Clean · breathable · calm',
    colors:['#f9f7f4','#2d2d2d','#6b8f71','#d4956a'],
    css:`
      :root{--bg:#f9f7f4;--bg2:#f3f0eb;--bg3:#ebe7e0;--bg4:#e0dbd2;--text:#2d2d2d;--text2:#7a7a7a;--text3:#a0a0a0;--accent:#6b8f71;--accent2:#d4956a;--accent3:#7b9ac9;--border:rgba(0,0,0,.08);--border2:rgba(0,0,0,.15);--r:12px;--r-lg:20px;--r-sm:8px;--shadow:0 2px 16px rgba(0,0,0,.06)}
      body{background:var(--bg);color:var(--text);font-family:var(--fb)}
      h1,h2,h3,h4,h5,h6{font-family:'Raleway','Georgia',sans-serif;font-weight:600;letter-spacing:-.01em;color:var(--text)}
      .ss-btn-p{background:var(--accent);color:#fff;border:none;border-radius:var(--r-lg);padding:13px 28px;font-weight:600;cursor:pointer;transition:all .3s ease;font-family:var(--fb);letter-spacing:.02em}
      .ss-btn-p:hover{background:#5a7e60;transform:translateY(-1px);box-shadow:0 6px 20px rgba(107,143,113,.3)}
      .ss-btn-s{background:transparent;border:1.5px solid var(--border2);color:var(--text2);border-radius:var(--r-lg);padding:12px 24px;font-weight:500;cursor:pointer;font-family:var(--fb);transition:all .3s}
      .ss-btn-s:hover{border-color:var(--accent);color:var(--accent)}
      .ss-card{background:#fff;border:1px solid rgba(0,0,0,.06);border-radius:var(--r-lg);padding:32px;box-shadow:var(--shadow);transition:all .3s}
      .ss-card:hover{box-shadow:0 8px 32px rgba(0,0,0,.1);transform:translateY(-2px)}
      .ss-badge{display:inline-flex;background:rgba(107,143,113,.1);border:1px solid rgba(107,143,113,.2);color:var(--accent);padding:6px 16px;border-radius:50px;font-size:13px;font-weight:500}
      .ss-kicker{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:2px;color:var(--accent);margin-bottom:14px}
      .ss-gtext{color:var(--accent);-webkit-text-fill-color:initial}
      .ss-input{background:#fff;border:1.5px solid var(--border2);border-radius:var(--r-sm);padding:13px 16px;color:var(--text);font-family:var(--fb);width:100%;outline:none;transition:border .2s}
      .ss-input:focus{border-color:var(--accent)}
      .ss-glass{background:rgba(255,255,255,.7);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.6);border-radius:var(--r-lg)}
    `},
];

const BLOCK_DEFAULT_STYLE = {
  backgroundType:'theme', backgroundColor:'#16161e',
  glass:{ color:'#ffffff', opacity:15, blur:12 },
  gradientFrom:'#0f0f13', gradientTo:'#1e1e28', gradientDir:'180deg',
  paddingTop:80, paddingBottom:80, borderRadius:0, textAlign:'center',
};

const GLOBAL_STYLE_DEFAULT = {
  fontHeading:'Syne', fontBody:'DM Sans',
  colorPrimary:'#ff6b35', colorSecondary:'#8b5cf6', colorBg:'#0f0f13', colorText:'#f0f0fa',
  borderRadius:'soft', spacing:'normal', theme:'liquid-glass',
};

// ── Utilities ────────────────────────────────────────────────────
let _uid = 0;
const uid = () => (++_uid).toString(36) + Math.random().toString(36).slice(2,6);
const el = (id) => document.getElementById(id);
const qs = (sel, ctx=document) => ctx.querySelector(sel);
const h = (tag, attr={}, children=[]) => {
  const e = document.createElement(tag);
  for (const [k,v] of Object.entries(attr)) {
    if (k==='cls') e.className = v;
    else if (k==='html') e.innerHTML = v;
    else if (k==='txt') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  children.forEach(c => { if (c != null) e.appendChild(typeof c==='string'?document.createTextNode(c):c); });
  return e;
};
const clone = (o) => JSON.parse(JSON.stringify(o));

// ── Toast ────────────────────────────────────────────────────────
function toast(msg, type='info') {
  let tc = el('toasts');
  if (!tc) { tc = document.createElement('div'); tc.id='toasts'; document.body.appendChild(tc); }
  const icons = { success:'✓', error:'✕', info:'i' };
  const t = h('div',{cls:`toast ${type}`},[h('span',{txt:icons[type]}),msg]);
  tc.appendChild(t);
  t.onclick = () => t.remove();
  setTimeout(() => t.remove(), 3400);
}

// ── Storage ──────────────────────────────────────────────────────
const store = {
  get: (k) => { try { return JSON.parse(localStorage.getItem(k)||'null'); } catch { return null; } },
  set: (k,v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  del: (k) => { try { localStorage.removeItem(k); } catch {} },
};

// ── App State ────────────────────────────────────────────────────
let APP = {
  screen: 'landing',   // 'landing' | 'builder'
  session: null,       // { sessionId, name, tier, code }
  project: null,       // ProjectState
  history: [], future: [],
  selectedId: null,
  sidebarTab: 'blocks',
  device: 'desktop',
  zoom: 100,
  wsConnected: false,
  collabUsers: [],
  showShareModal: false,
  showPreview: false,
  loginTab: 'code',
  faqOpen: null,
  faqData: {},
};

// ── Block Defaults ────────────────────────────────────────────────
function makeBlock(type) {
  return { id: uid(), type, style: clone(BLOCK_DEFAULT_STYLE), hidden: false, data: blockDefaults(type) };
}
function blockDefaults(type) {
  const id = () => uid();
  const data = { nav:{
    logo:'MySite', sticky:true,
    links:[{label:'Features',href:'#features'},{label:'Pricing',href:'#pricing'},{label:'About',href:'#about'}],
    ctaLabel:'Get Started', ctaHref:'#',
  }, hero:{
    badge:'Introducing v2.0', heading:'Build Stunning Websites Fast',
    subheading:'A powerful visual builder that helps you create beautiful, production-ready websites without writing a single line of code.',
    ctaPrimaryLabel:'Get Started Free', ctaPrimaryHref:'#', ctaSecondaryLabel:'Watch Demo', ctaSecondaryHref:'#',
    showStats:true, stats:[{num:'10K+',label:'Users'},{num:'50K+',label:'Sites Built'},{num:'99%',label:'Uptime'}],
  }, features:{
    heading:'Everything You Need', subheading:'Powerful features designed for teams that ship fast.', layout:'grid3',
    items:[
      {icon:'⚡',title:'Lightning Fast',desc:'Optimized for performance. Your sites load instantly.'},
      {icon:'🛡',title:'Secure by Default',desc:'Enterprise-grade security built in, not bolted on.'},
      {icon:'🌐',title:'Global CDN',desc:'Deploy to 100+ edge locations worldwide in one click.'},
      {icon:'💻',title:'Clean Code Export',desc:'Export production-ready HTML with all styles.'},
      {icon:'🎨',title:'5 Pro Themes',desc:'Hand-crafted design systems. Switch in seconds.'},
      {icon:'👥',title:'Live Collab',desc:'Real-time collaboration. See changes as they happen.'},
    ],
  }, pricing:{
    heading:'Simple, Transparent Pricing', subheading:'Start free. Scale as you grow.',
    tiers:[
      {name:'Starter',price:'$0',period:'/mo',desc:'For personal projects.',features:['1 project','6 blocks','Basic themes','HTML export'],cta:'Get Started',featured:false},
      {name:'Basic',price:'$19',period:'/mo',desc:'For freelancers.',features:['3 projects','20 blocks','All themes','Share codes'],cta:'Start Basic',featured:false},
      {name:'Pro',price:'$49',period:'/mo',desc:'For growing businesses.',features:['10 projects','Unlimited blocks','Live collaboration','Priority support'],cta:'Start Pro',featured:true},
      {name:'Agency',price:'$149',period:'/mo',desc:'For agencies.',features:['Unlimited projects','Custom webhooks','White-label','SLA guarantee'],cta:'Contact Sales',featured:false},
    ],
  }, testimonials:{
    heading:'Loved by Teams Worldwide', subheading:"Here's what our customers say.",
    items:[
      {quote:'Supersuite cut our landing page time from 2 weeks to 2 hours.',author:'Sarah Chen',role:'Head of Marketing',company:'TechCorp',rating:5},
      {quote:"The best visual builder I've ever used. Clean code, fast exports.",author:'Marcus Webb',role:'Founder',company:'Launchpad',rating:5},
      {quote:'Our whole team uses it. The live collab feature alone is worth the price.',author:'Priya Nair',role:'Lead Designer',company:'PixelStudio',rating:5},
    ],
  }, cta:{
    heading:'Ready to Build Something Great?', subheading:'Join 10,000+ teams who ship faster with Supersuite.',
    ctaPrimaryLabel:'Start Building Free', ctaPrimaryHref:'#', ctaSecondaryLabel:'Talk to Sales', ctaSecondaryHref:'#',
    style:'banner',
  }, gallery:{
    heading:'Our Work', subheading:'A selection of recent projects.', layout:'grid',
    images:[
      {url:'https://placehold.co/400x280/1a1a2e/ff6b35?text=Project+1',alt:'Project 1',caption:'E-commerce Platform'},
      {url:'https://placehold.co/400x280/16213e/a78bfa?text=Project+2',alt:'Project 2',caption:'SaaS Dashboard'},
      {url:'https://placehold.co/400x280/0f3460/60a5fa?text=Project+3',alt:'Project 3',caption:'Marketing Site'},
      {url:'https://placehold.co/400x280/1a1a2e/22c55e?text=Project+4',alt:'Project 4',caption:'Mobile App'},
      {url:'https://placehold.co/400x280/16213e/f59e0b?text=Project+5',alt:'Project 5',caption:'Portfolio'},
      {url:'https://placehold.co/400x280/0f3460/ef4444?text=Project+6',alt:'Project 6',caption:'Agency Site'},
    ],
  }, widget:{
    heading:'Launching Soon', widgetType:'countdown', embedUrl:'',
    targetDate: new Date(Date.now()+7*864e5).toISOString().split('T')[0],
  }, footer:{
    logo:'MySite', tagline:'Building the future, one site at a time.', copyright:`© ${new Date().getFullYear()} MySite. All rights reserved.`,
    showSocials:true, social:{twitter:'https://twitter.com',linkedin:'https://linkedin.com',github:'https://github.com',instagram:'https://instagram.com'},
    columns:[
      {heading:'Product',links:[{label:'Features',href:'#'},{label:'Pricing',href:'#'},{label:'Changelog',href:'#'}]},
      {heading:'Company',links:[{label:'About',href:'#'},{label:'Blog',href:'#'},{label:'Careers',href:'#'}]},
      {heading:'Legal',links:[{label:'Privacy',href:'#'},{label:'Terms',href:'#'},{label:'Security',href:'#'}]},
    ],
  }, leadform:{
    heading:'Get In Touch', subheading:"Fill out the form and we'll get back to you within 24 hours.",
    fields:[
      {id:id(),type:'text',label:'Full Name',placeholder:'John Doe',required:true},
      {id:id(),type:'email',label:'Email Address',placeholder:'john@example.com',required:true},
      {id:id(),type:'textarea',label:'Message',placeholder:'Tell us about your project...',required:true},
    ],
    submitLabel:'Send Message', successMessage:"Thanks! We'll be in touch soon.", webhookUrl:'',
  }};
  return data[type] || {};
}

function createProject(name='My Awesome Site') {
  return {
    version:1, siteName:name,
    globalStyles: clone(GLOBAL_STYLE_DEFAULT),
    blocks: ['nav','hero','features','pricing','cta','footer'].map(makeBlock),
  };
}

// ── State mutations ────────────────────────────────────────────────
function pushState(newProj) {
  APP.history.push(clone(APP.project));
  if (APP.history.length > 60) APP.history.shift();
  APP.future = [];
  APP.project = { ...newProj, version: (newProj.version||0)+1 };
  store.set('ss-project-'+APP.session.sessionId, APP.project);
  refreshCanvas();
  refreshRightPanel();
  refreshLayers();
  refreshStatus();
}
function undo() {
  if (!APP.history.length) return;
  APP.future.unshift(clone(APP.project));
  APP.project = APP.history.pop();
  store.set('ss-project-'+APP.session.sessionId, APP.project);
  refreshCanvas(); refreshRightPanel(); refreshLayers(); refreshStatus();
}
function redo() {
  if (!APP.future.length) return;
  APP.history.push(clone(APP.project));
  APP.project = APP.future.shift();
  store.set('ss-project-'+APP.session.sessionId, APP.project);
  refreshCanvas(); refreshRightPanel(); refreshLayers(); refreshStatus();
}

// ── HTML Renderer ─────────────────────────────────────────────────
function renderPage(proj) {
  const gs = proj.globalStyles;
  const theme = THEMES.find(t=>t.id===gs.theme) || THEMES[0];
  const fontMap = { 'Syne':'Syne','DM Sans':'DM+Sans:opsz,wght@9..40,400;9..40,600','Space Grotesk':'Space+Grotesk','Playfair Display':'Playfair+Display','Raleway':'Raleway' };
  const fonts = [...new Set([gs.fontHeading,gs.fontBody])].map(f=>fontMap[f]||f).join('&family=');
  const blocks = proj.blocks.filter(b=>!b.hidden).map(b=>renderBlock(b,gs)).join('\n');
  return `<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>${esc(proj.siteName)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=${fonts}&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--fh:'${gs.fontHeading}',system-ui,sans-serif;--fb:'${gs.fontBody}',system-ui,sans-serif}
${theme.css}
html,body{height:100%;line-height:1.6}img{max-width:100%}a{text-decoration:none}
@media(max-width:768px){[style*="repeat(3"]{grid-template-columns:1fr!important}[style*="repeat(4"]{grid-template-columns:1fr 1fr!important}}
</style></head><body>${blocks}</body></html>`;
}

function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

function blockStyleCSS(s) {
  const parts = [];
  if (s.backgroundType==='glass') {
    const rgb = hexToRgb(s.glass.color);
    if (rgb) {
      parts.push(`background:rgba(${rgb.r},${rgb.g},${rgb.b},${s.glass.opacity/100})`);
      parts.push(`backdrop-filter:blur(${s.glass.blur}px);-webkit-backdrop-filter:blur(${s.glass.blur}px)`);
    }
  } else if (s.backgroundType==='solid') {
    parts.push(`background:${s.backgroundColor}`);
  } else if (s.backgroundType==='gradient') {
    parts.push(`background:linear-gradient(${s.gradientDir},${s.gradientFrom},${s.gradientTo})`);
  }
  parts.push(`padding-top:${s.paddingTop}px;padding-bottom:${s.paddingBottom}px`);
  if (s.borderRadius) parts.push(`border-radius:${s.borderRadius}px;overflow:hidden`);
  parts.push(`text-align:${s.textAlign}`);
  return parts.join(';');
}
function hexToRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? {r:parseInt(r[1],16),g:parseInt(r[2],16),b:parseInt(r[3],16)} : null;
}

function renderBlock(b, gs) {
  const s = blockStyleCSS(b.style);
  const d = b.data;
  switch(b.type) {
    case 'nav': return `<nav style="background:var(--bg2);border-bottom:1px solid var(--border);padding:0 24px;display:flex;align-items:center;gap:24px;height:64px;${d.sticky?'position:sticky;top:0;z-index:100;backdrop-filter:blur(16px);':''}">
  <div style="font-family:var(--fh);font-weight:800;font-size:20px;flex-shrink:0;">${esc(d.logo)}</div>
  <nav style="display:flex;align-items:center;gap:24px;flex:1;">${d.links.map(l=>`<a href="${esc(l.href)}" style="color:var(--text2);font-size:14px;font-weight:500;">${esc(l.label)}</a>`).join('')}</nav>
  <a href="${esc(d.ctaHref)}" class="ss-btn-p" style="font-size:13px;padding:9px 20px;">${esc(d.ctaLabel)}</a>
</nav>`;
    case 'hero': return `<section style="${s};position:relative;">
  <div style="max-width:820px;margin:0 auto;padding:0 24px;">
    ${d.badge?`<div class="ss-badge" style="margin-bottom:22px;">${esc(d.badge)}</div>`:''}
    <h1 class="ss-gtext" style="font-size:clamp(34px,6vw,70px);margin-bottom:18px;">${esc(d.heading)}</h1>
    <p style="font-size:18px;color:var(--text2);max-width:600px;margin:0 auto 30px;line-height:1.75;">${esc(d.subheading)}</p>
    <div style="display:flex;gap:12px;flex-wrap:wrap;justify-content:center;margin-bottom:${d.showStats?'32px':'0'};">
      <a href="${esc(d.ctaPrimaryHref)}" class="ss-btn-p">${esc(d.ctaPrimaryLabel)}</a>
      <a href="${esc(d.ctaSecondaryHref)}" class="ss-btn-s">${esc(d.ctaSecondaryLabel)}</a>
    </div>
    ${d.showStats&&d.stats.length?`<div style="display:flex;align-items:center;justify-content:center;gap:28px;flex-wrap:wrap;">${d.stats.map((s,i)=>`${i?'<div style="width:1px;height:36px;background:var(--border2)"></div>':''}<div style="text-align:center;"><div style="font-family:var(--fh);font-size:30px;font-weight:800;letter-spacing:-1px;">${esc(s.num)}</div><div style="font-size:12px;color:var(--text2);">${esc(s.label)}</div></div>`).join('')}</div>`:''}
  </div>
</section>`;
    case 'features': return `<section style="${s};">
  <div style="max-width:1160px;margin:0 auto;padding:0 24px;">
    <div style="margin-bottom:44px;">
      <div class="ss-kicker">${esc(d.heading)}</div>
      <h2 style="font-size:clamp(26px,4vw,46px);margin-bottom:12px;">${esc(d.heading)}</h2>
      <p style="font-size:16px;color:var(--text2);max-width:540px;margin:0 auto;line-height:1.75;">${esc(d.subheading)}</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(${d.layout==='grid2'?2:3},1fr);gap:22px;">
      ${d.items.map(item=>`<div class="ss-card"><div style="font-size:22px;margin-bottom:12px;">${item.icon}</div><h3 style="font-size:16px;margin-bottom:7px;">${esc(item.title)}</h3><p style="font-size:13px;color:var(--text2);line-height:1.7;">${esc(item.desc)}</p></div>`).join('')}
    </div>
  </div>
</section>`;
    case 'pricing': return `<section style="${s};">
  <div style="max-width:1160px;margin:0 auto;padding:0 24px;text-align:center;">
    <h2 style="font-size:clamp(26px,4vw,46px);margin-bottom:12px;">${esc(d.heading)}</h2>
    <p style="font-size:16px;color:var(--text2);margin-bottom:44px;line-height:1.7;">${esc(d.subheading)}</p>
    <div style="display:grid;grid-template-columns:repeat(${d.tiers.length},1fr);gap:18px;align-items:start;">
      ${d.tiers.map(t=>`<div class="ss-card" style="${t.featured?'border-color:var(--accent);transform:scale(1.02);':''}">${t.featured?`<div style="display:inline-block;background:var(--accent);color:#fff;font-size:10px;font-weight:700;padding:3px 12px;border-radius:20px;margin-bottom:10px;">Most Popular</div>`:''}
        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text2);margin-bottom:7px;">${esc(t.name)}</div>
        <div style="font-size:46px;font-weight:800;letter-spacing:-2px;font-family:var(--fh);line-height:1;">${esc(t.price)}<span style="font-size:14px;font-weight:500;color:var(--text2);">${esc(t.period)}</span></div>
        <p style="font-size:12px;color:var(--text2);margin:8px 0 16px;line-height:1.5;">${esc(t.desc)}</p>
        <ul style="list-style:none;display:flex;flex-direction:column;gap:7px;margin-bottom:20px;text-align:left;">${t.features.map(f=>`<li style="font-size:12px;display:flex;align-items:center;gap:7px;"><span style="color:var(--accent);font-weight:700;">✓</span>${esc(f)}</li>`).join('')}</ul>
        <button class="ss-btn-p" style="width:100%;">${esc(t.cta)}</button>
      </div>`).join('')}
    </div>
  </div>
</section>`;
    case 'testimonials': return `<section style="${s};">
  <div style="max-width:1160px;margin:0 auto;padding:0 24px;text-align:center;">
    <h2 style="font-size:clamp(26px,4vw,46px);margin-bottom:12px;">${esc(d.heading)}</h2>
    <p style="font-size:16px;color:var(--text2);margin-bottom:44px;line-height:1.7;">${esc(d.subheading)}</p>
    <div style="display:grid;grid-template-columns:repeat(${Math.min(d.items.length,3)},1fr);gap:22px;">
      ${d.items.map(i=>`<div class="ss-card" style="text-align:left;"><div style="color:var(--accent);font-size:18px;margin-bottom:10px;">${'★'.repeat(i.rating)}</div><p style="font-size:14px;line-height:1.8;margin-bottom:16px;font-style:italic;">"${esc(i.quote)}"</p><div style="display:flex;align-items:center;gap:10px;"><div style="width:38px;height:38px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;color:#fff;flex-shrink:0;">${esc(i.author.charAt(0))}</div><div><div style="font-size:12px;font-weight:700;">${esc(i.author)}</div><div style="font-size:11px;color:var(--text2);">${esc(i.role)} · ${esc(i.company)}</div></div></div></div>`).join('')}
    </div>
  </div>
</section>`;
    case 'cta': return `<section style="${s};background:${d.style==='banner'?'linear-gradient(135deg,var(--accent),#ff3d00)':'var(--bg2)'};">
  <div style="max-width:740px;margin:0 auto;padding:0 24px;text-align:center;">
    <h2 style="font-size:clamp(26px,4vw,46px);margin-bottom:14px;color:${d.style==='banner'?'#fff':'var(--text)'};">${esc(d.heading)}</h2>
    <p style="font-size:17px;color:${d.style==='banner'?'rgba(255,255,255,.85)':'var(--text2)'};margin-bottom:30px;line-height:1.7;">${esc(d.subheading)}</p>
    <div style="display:flex;gap:12px;flex-wrap:wrap;justify-content:center;">
      <a href="${esc(d.ctaPrimaryHref)}" class="ss-btn-p" style="${d.style==='banner'?'background:#fff;color:#ff6b35;':''}">${esc(d.ctaPrimaryLabel)}</a>
      <a href="${esc(d.ctaSecondaryHref)}" class="ss-btn-s" style="${d.style==='banner'?'border-color:rgba(255,255,255,.5);color:#fff;':''}">${esc(d.ctaSecondaryLabel)}</a>
    </div>
  </div>
</section>`;
    case 'gallery': return `<section style="${s};">
  <div style="max-width:1160px;margin:0 auto;padding:0 24px;text-align:center;">
    <h2 style="font-size:clamp(26px,4vw,46px);margin-bottom:12px;">${esc(d.heading)}</h2>
    <p style="font-size:16px;color:var(--text2);margin-bottom:40px;line-height:1.7;">${esc(d.subheading)}</p>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;">
      ${d.images.map(img=>`<div style="border-radius:var(--r-lg);overflow:hidden;background:var(--bg2);"><img src="${esc(img.url)}" alt="${esc(img.alt)}" style="width:100%;height:190px;object-fit:cover;" onerror="this.src='https://placehold.co/400x190/1a1a2e/666?text=Image'">${img.caption?`<div style="padding:8px 12px;font-size:12px;color:var(--text2);text-align:left;">${esc(img.caption)}</div>`:''}</div>`).join('')}
    </div>
  </div>
</section>`;
    case 'widget': return `<section style="${s};">
  <div style="max-width:740px;margin:0 auto;padding:0 24px;text-align:center;">
    <h2 style="font-size:clamp(26px,4vw,40px);margin-bottom:24px;">${esc(d.heading)}</h2>
    ${d.widgetType==='countdown'?`<div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;" id="cd-${b.id}">
      ${['Days','Hours','Minutes','Seconds'].map((u,i)=>`<div style="background:var(--bg2);border:1px solid var(--border2);border-radius:var(--r-lg);padding:18px 22px;min-width:76px;"><div style="font-family:var(--fh);font-size:46px;font-weight:800;color:var(--accent);" id="cd${i}-${b.id}">00</div><div style="font-size:11px;color:var(--text2);text-transform:uppercase;letter-spacing:1px;">${u}</div></div>`).join('')}
    </div>
    <script>(function(){var t=new Date("${esc(d.targetDate)}").getTime();function u(){var n=Date.now(),d=Math.max(0,t-n),s=Math.floor(d/1e3)%60,m=Math.floor(d/6e4)%60,h=Math.floor(d/36e5)%24,dy=Math.floor(d/864e5);var p=function(x){return x<10?'0'+x:''+x};['cd0','cd1','cd2','cd3'].forEach(function(id,i){var e=document.getElementById(id+'-${b.id}');if(e)e.textContent=p([dy,h,m,s][i])});}u();setInterval(u,1000)})();</scr`+'ipt>':d.embedUrl?`<iframe src="${esc(d.embedUrl)}" style="width:100%;height:380px;border:none;border-radius:var(--r-lg);" allowfullscreen></iframe>`:`<div style="background:var(--bg2);border:1px dashed var(--border2);border-radius:var(--r-lg);height:280px;display:flex;align-items:center;justify-content:center;color:var(--text2);">Set an embed URL or countdown date</div>`}
  </div>
</section>`;
    case 'footer': return `<footer style="${s};background:var(--bg2);border-top:1px solid var(--border);">
  <div style="max-width:1160px;margin:0 auto;padding:0 24px;">
    <div style="display:grid;grid-template-columns:1fr ${d.columns.map(()=>'1fr').join(' ')};gap:36px;margin-bottom:36px;">
      <div><div style="font-family:var(--fh);font-weight:800;font-size:19px;margin-bottom:9px;">${esc(d.logo)}</div>
        <p style="font-size:13px;color:var(--text2);line-height:1.7;margin-bottom:14px;">${esc(d.tagline)}</p>
        ${d.showSocials?`<div style="display:flex;gap:7px;">${['twitter','linkedin','github'].filter(k=>d.social[k]).map(k=>`<a href="${esc(d.social[k])}" style="color:var(--text2);background:var(--bg3);width:34px;height:34px;border-radius:7px;display:inline-flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;">${k==='twitter'?'𝕏':k==='linkedin'?'in':'gh'}</a>`).join('')}</div>`:''}
      </div>
      ${d.columns.map(col=>`<div><div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text2);margin-bottom:14px;">${esc(col.heading)}</div><div style="display:flex;flex-direction:column;gap:8px;">${col.links.map(l=>`<a href="${esc(l.href)}" style="font-size:13px;color:var(--text2);">${esc(l.label)}</a>`).join('')}</div></div>`).join('')}
    </div>
    <div style="border-top:1px solid var(--border);padding-top:18px;"><div style="font-size:12px;color:var(--text2);">${esc(d.copyright)}</div></div>
  </div>
</footer>`;
    case 'leadform': return `<section style="${s};">
  <div style="max-width:620px;margin:0 auto;padding:0 24px;">
    <div style="text-align:center;margin-bottom:36px;">
      <h2 style="font-size:clamp(26px,4vw,40px);margin-bottom:12px;">${esc(d.heading)}</h2>
      <p style="font-size:16px;color:var(--text2);line-height:1.7;">${esc(d.subheading)}</p>
    </div>
    <form class="ss-card" id="f-${b.id}" onsubmit="event.preventDefault();document.getElementById('f-${b.id}').style.display='none';document.getElementById('fs-${b.id}').style.display='block';" style="display:flex;flex-direction:column;gap:14px;">
      ${d.fields.map(f=>`<div><label style="display:block;font-size:13px;font-weight:600;margin-bottom:5px;">${esc(f.label)}${f.required?'<span style="color:var(--accent);"> *</span>':''}</label>${f.type==='textarea'?`<textarea class="ss-input" placeholder="${esc(f.placeholder)}" ${f.required?'required':''} style="min-height:90px;"></textarea>`:f.type==='select'?`<select class="ss-input" ${f.required?'required':''}><option value="">Select...</option></select>`:`<input type="${f.type}" class="ss-input" placeholder="${esc(f.placeholder)}" ${f.required?'required':''}>`}</div>`).join('')}
      <button type="submit" class="ss-btn-p" style="width:100%;">${esc(d.submitLabel)}</button>
    </form>
    <div id="fs-${b.id}" style="display:none;" class="ss-card"><div style="text-align:center;padding:20px 0;"><div style="font-size:32px;margin-bottom:10px;">✓</div><p style="font-size:15px;font-weight:600;">${esc(d.successMessage)}</p></div></div>
  </div>
</section>`;
    default: return `<section style="${s};"><p style="text-align:center;color:var(--text2);">Unknown block</p></section>`;
  }
}

// ── Canvas refresh ────────────────────────────────────────────────
function refreshCanvas() {
  const iframe = el('preview-iframe');
  if (!iframe || !APP.project) return;
  const doc = iframe.contentDocument || iframe.contentWindow.document;
  doc.open(); doc.write(renderPage(APP.project)); doc.close();
}

// ── Layers refresh ────────────────────────────────────────────────
function refreshLayers() {
  const list = el('layers-list');
  if (!list || !APP.project) return;
  const blocks = APP.project.blocks;
  list.innerHTML = '';
  if (!blocks.length) {
    list.innerHTML = '<div style="padding:16px;text-align:center;font-size:11px;color:var(--text2);">No blocks. Add from Blocks tab.</div>';
    return;
  }
  blocks.forEach((b, idx) => {
    const def = BLOCK_DEFS.find(d=>d.type===b.type) || { label:b.type };
    const row = h('div', { cls:'layer-item'+(APP.selectedId===b.id?' active':'')+(b.hidden?' hidden':'') }, [
      h('span',{cls:'layer-grab',txt:'⠿'}),
      h('span',{cls:'layer-lbl',txt:def.label}),
      h('div',{cls:'layer-btns'},[
        h('button',{cls:'layer-btn',txt:b.hidden?'○':'●',title:b.hidden?'Show':'Hide',onclick:(e)=>{ e.stopPropagation(); toggleHide(b.id); }}),
        h('button',{cls:'layer-btn',txt:'↑',title:'Move up',onclick:(e)=>{ e.stopPropagation(); moveBlock(b.id,-1); }}),
        h('button',{cls:'layer-btn',txt:'↓',title:'Move down',onclick:(e)=>{ e.stopPropagation(); moveBlock(b.id,1); }}),
        h('button',{cls:'layer-btn danger',txt:'✕',title:'Delete',onclick:(e)=>{ e.stopPropagation(); deleteBlock(b.id); }}),
      ]),
    ]);
    row.addEventListener('click', ()=>selectBlock(b.id));
    list.appendChild(row);
  });
}

// ── Status refresh ────────────────────────────────────────────────
function refreshStatus() {
  const saved = el('status-saved');
  const blocks = el('status-blocks');
  if (!APP.project) return;
  if (saved) saved.textContent = 'Saved';
  if (blocks) blocks.textContent = `${APP.project.blocks.length} / ${TIER_LIMITS[APP.session.tier].blocks} blocks`;
  const undoBtn = el('undo-btn');
  const redoBtn = el('redo-btn');
  if (undoBtn) undoBtn.disabled = APP.history.length === 0;
  if (redoBtn) redoBtn.disabled = APP.future.length === 0;
}

// ── Block operations ──────────────────────────────────────────────
function selectBlock(id) {
  APP.selectedId = id;
  refreshLayers();
  refreshRightPanel();
  const info = el('canvas-editing');
  const b = APP.project.blocks.find(x=>x.id===id);
  if (info && b) info.textContent = ' · Editing: ' + (BLOCK_DEFS.find(d=>d.type===b.type)||{label:b.type}).label;
}
function addBlock(type) {
  const lim = TIER_LIMITS[APP.session.tier].blocks;
  if (APP.project.blocks.length >= lim) {
    toast(`Block limit reached (${lim} for ${APP.session.tier}). Upgrade to add more.`, 'error');
    return;
  }
  const b = makeBlock(type);
  pushState({ ...APP.project, blocks: [...APP.project.blocks, b] });
  selectBlock(b.id);
  switchSidebarTab('layers');
  toast(`${(BLOCK_DEFS.find(d=>d.type===type)||{label:type}).label} block added`, 'success');
}
function deleteBlock(id) {
  const blocks = APP.project.blocks.filter(b=>b.id!==id);
  pushState({ ...APP.project, blocks });
  if (APP.selectedId===id) { APP.selectedId=null; refreshRightPanel(); }
}
function toggleHide(id) {
  const blocks = APP.project.blocks.map(b=>b.id===id?{...b,hidden:!b.hidden}:b);
  pushState({ ...APP.project, blocks });
}
function moveBlock(id, dir) {
  const blocks = [...APP.project.blocks];
  const idx = blocks.findIndex(b=>b.id===id);
  const nIdx = idx+dir;
  if (nIdx<0||nIdx>=blocks.length) return;
  [blocks[idx],blocks[nIdx]] = [blocks[nIdx],blocks[idx]];
  pushState({ ...APP.project, blocks });
}
function updateBlockData(id, data) {
  const blocks = APP.project.blocks.map(b=>b.id===id?{...b,data:{...b.data,...data}}:b);
  pushState({ ...APP.project, blocks });
}
function updateBlockStyle(id, style) {
  const blocks = APP.project.blocks.map(b=>b.id===id?{...b,style:{...b.style,...style}}:b);
  pushState({ ...APP.project, blocks });
}
function updateGS(gs) {
  pushState({ ...APP.project, globalStyles: {...APP.project.globalStyles,...gs} });
}

// ── Right panel ───────────────────────────────────────────────────
function refreshRightPanel() {
  const body = el('rp-body');
  const header = el('rp-title');
  if (!body) return;
  if (!APP.selectedId || !APP.project) {
    if (header) header.textContent = 'Properties';
    body.innerHTML = `<div class="rp-empty"><div class="rp-empty-icon">◑</div><p>Select a block from the Layers panel to edit its content and style.</p><button class="btn btn-ghost btn-sm" onclick="switchSidebarTab('layers')" style="margin-top:8px;">Open Layers</button></div>`;
    return;
  }
  const b = APP.project.blocks.find(x=>x.id===APP.selectedId);
  if (!b) { body.innerHTML=''; return; }
  const def = BLOCK_DEFS.find(d=>d.type===b.type)||{label:b.type};
  if (header) header.textContent = 'Edit ' + def.label;
  body.innerHTML = buildBlockEditor(b);
  attachBlockEditorEvents(b);
}

function buildBlockEditor(b) {
  return `
  <div class="rp-block-controls">
    <span class="rp-block-type">${b.type}</span>
    <div class="rp-block-btns">
      <button class="btn btn-ghost btn-icon btn-sm" onclick="moveBlock('${b.id}',-1)" title="Move up">↑</button>
      <button class="btn btn-ghost btn-icon btn-sm" onclick="moveBlock('${b.id}',1)" title="Move down">↓</button>
      <button class="btn btn-ghost btn-icon btn-sm" onclick="toggleHide('${b.id}')" title="${b.hidden?'Show':'Hide'}">${b.hidden?'○':'●'}</button>
      <button class="btn btn-danger btn-icon btn-sm" onclick="deleteBlock('${b.id}')" title="Delete">✕</button>
    </div>
  </div>
  <div class="rp-section open" id="rps-content-${b.id}">
    <div class="rp-section-hd" onclick="toggleRpSection('rps-content-${b.id}')"><span>Content</span><span class="arr">▾</span></div>
    <div class="rp-section-body">${buildContentEditor(b)}</div>
  </div>
  <div class="rp-section open" id="rps-style-${b.id}">
    <div class="rp-section-hd" onclick="toggleRpSection('rps-style-${b.id}')"><span>Block Style</span><span class="arr">▾</span></div>
    <div class="rp-section-body">${buildStyleEditor(b)}</div>
  </div>`;
}

function toggleRpSection(id) {
  const sec = el(id);
  if (sec) sec.classList.toggle('open');
}

function buildStyleEditor(b) {
  const s = b.style;
  return `
  <div class="rp-field">
    <label>Background</label>
    <select onchange="updateBlockStyle('${b.id}',{backgroundType:this.value});refreshRightPanel()">
      ${['theme','glass','solid','gradient'].map(v=>`<option value="${v}"${s.backgroundType===v?' selected':''}>${v.charAt(0).toUpperCase()+v.slice(1)}</option>`).join('')}
    </select>
  </div>
  ${s.backgroundType==='glass'?`
  <div class="rp-field"><label>Glass Color</label><div style="display:flex;gap:5px;align-items:center;"><input type="color" value="${s.glass.color}" oninput="updateBlockStyle('${b.id}',{glass:{...APP.project.blocks.find(b=>b.id==='${b.id}').style.glass,color:this.value}})"><input type="text" value="${s.glass.color}" oninput="updateBlockStyle('${b.id}',{glass:{...APP.project.blocks.find(b=>b.id==='${b.id}').style.glass,color:this.value}})" style="flex:1;font-family:monospace;font-size:11px;"></div></div>
  <div class="rp-field"><label>Opacity: <span id="go-${b.id}">${s.glass.opacity}%</span></label><input type="range" min="0" max="60" value="${s.glass.opacity}" oninput="el('go-${b.id}').textContent=this.value+'%';updateBlockStyle('${b.id}',{glass:{...APP.project.blocks.find(b=>b.id==='${b.id}').style.glass,opacity:+this.value}})"></div>
  <div class="rp-field"><label>Blur: <span id="gb-${b.id}">${s.glass.blur}px</span></label><input type="range" min="0" max="40" value="${s.glass.blur}" oninput="el('gb-${b.id}').textContent=this.value+'px';updateBlockStyle('${b.id}',{glass:{...APP.project.blocks.find(b=>b.id==='${b.id}').style.glass,blur:+this.value}})"></div>
  `:''}
  ${s.backgroundType==='solid'?`<div class="rp-field"><label>Color</label><div style="display:flex;gap:5px;align-items:center;"><input type="color" value="${s.backgroundColor}" oninput="updateBlockStyle('${b.id}',{backgroundColor:this.value})"><input type="text" value="${s.backgroundColor}" oninput="updateBlockStyle('${b.id}',{backgroundColor:this.value})" style="flex:1;font-family:monospace;font-size:11px;"></div></div>`:''}
  ${s.backgroundType==='gradient'?`
  <div class="rp-field"><label>From</label><div style="display:flex;gap:5px;align-items:center;"><input type="color" value="${s.gradientFrom}" oninput="updateBlockStyle('${b.id}',{gradientFrom:this.value})"><input type="text" value="${s.gradientFrom}" oninput="updateBlockStyle('${b.id}',{gradientFrom:this.value})" style="flex:1;font-family:monospace;font-size:11px;"></div></div>
  <div class="rp-field"><label>To</label><div style="display:flex;gap:5px;align-items:center;"><input type="color" value="${s.gradientTo}" oninput="updateBlockStyle('${b.id}',{gradientTo:this.value})"><input type="text" value="${s.gradientTo}" oninput="updateBlockStyle('${b.id}',{gradientTo:this.value})" style="flex:1;font-family:monospace;font-size:11px;"></div></div>
  <div class="rp-field"><label>Direction</label><select onchange="updateBlockStyle('${b.id}',{gradientDir:this.value})">
    ${[['180deg','Top→Bottom'],['90deg','Left→Right'],['135deg','Diagonal↘'],['45deg','Diagonal↗']].map(([v,l])=>`<option value="${v}"${s.gradientDir===v?' selected':''}>${l}</option>`).join('')}
  </select></div>`:''}
  <div class="rp-field"><label>Pad Top: <span id="pt-${b.id}">${s.paddingTop}px</span></label><input type="range" min="0" max="200" value="${s.paddingTop}" oninput="el('pt-${b.id}').textContent=this.value+'px';updateBlockStyle('${b.id}',{paddingTop:+this.value})"></div>
  <div class="rp-field"><label>Pad Bottom: <span id="pb-${b.id}">${s.paddingBottom}px</span></label><input type="range" min="0" max="200" value="${s.paddingBottom}" oninput="el('pb-${b.id}').textContent=this.value+'px';updateBlockStyle('${b.id}',{paddingBottom:+this.value})"></div>
  <div class="rp-field"><label>Radius: <span id="br-${b.id}">${s.borderRadius}px</span></label><input type="range" min="0" max="48" value="${s.borderRadius}" oninput="el('br-${b.id}').textContent=this.value+'px';updateBlockStyle('${b.id}',{borderRadius:+this.value})"></div>
  <div class="rp-field"><label>Text Align</label><select onchange="updateBlockStyle('${b.id}',{textAlign:this.value})">
    ${['left','center','right'].map(v=>`<option value="${v}"${s.textAlign===v?' selected':''}>${v.charAt(0).toUpperCase()+v.slice(1)}</option>`).join('')}
  </select></div>
  <button class="btn btn-ghost btn-sm" style="width:100%;margin-top:4px;" onclick="updateBlockStyle('${b.id}',${JSON.stringify(BLOCK_DEFAULT_STYLE)});refreshRightPanel()">Reset Style</button>`;
}

function buildContentEditor(b) {
  const d = b.data;
  switch(b.type) {
    case 'nav': return `
      <div class="rp-field"><label>Logo Text</label><input type="text" value="${esc(d.logo)}" oninput="updateBlockData('${b.id}',{logo:this.value})"></div>
      <div class="rp-field"><label>CTA Label</label><input type="text" value="${esc(d.ctaLabel)}" oninput="updateBlockData('${b.id}',{ctaLabel:this.value})"></div>
      <div class="rp-field"><label>CTA URL</label><input type="url" value="${esc(d.ctaHref)}" oninput="updateBlockData('${b.id}',{ctaHref:this.value})"></div>
      <div class="rp-field" style="display:flex;align-items:center;gap:8px;"><label style="margin:0;">Sticky</label><input type="checkbox" ${d.sticky?'checked':''} onchange="updateBlockData('${b.id}',{sticky:this.checked})"></div>
      <div class="label" style="margin-top:8px;">Nav Links</div>
      <div id="nav-links-${b.id}">${d.links.map((l,i)=>`<div style="display:flex;gap:4px;margin-bottom:4px;"><input type="text" value="${esc(l.label)}" placeholder="Label" oninput="navLinkUpdate('${b.id}',${i},'label',this.value)" style="flex:1"><input type="text" value="${esc(l.href)}" placeholder="URL" oninput="navLinkUpdate('${b.id}',${i},'href',this.value)" style="flex:1"><button class="btn btn-danger btn-icon btn-sm" onclick="navLinkDel('${b.id}',${i})">✕</button></div>`).join('')}</div>
      <button class="btn btn-ghost btn-sm" style="width:100%;margin-top:4px;" onclick="navLinkAdd('${b.id}')">+ Add Link</button>`;
    case 'hero': return `
      <div class="rp-field"><label>Badge</label><input type="text" value="${esc(d.badge)}" oninput="updateBlockData('${b.id}',{badge:this.value})"></div>
      <div class="rp-field"><label>Heading</label><textarea rows="2" oninput="updateBlockData('${b.id}',{heading:this.value})">${esc(d.heading)}</textarea></div>
      <div class="rp-field"><label>Subheading</label><textarea rows="3" oninput="updateBlockData('${b.id}',{subheading:this.value})">${esc(d.subheading)}</textarea></div>
      <div class="rp-field"><label>Primary CTA Label</label><input type="text" value="${esc(d.ctaPrimaryLabel)}" oninput="updateBlockData('${b.id}',{ctaPrimaryLabel:this.value})"></div>
      <div class="rp-field"><label>Secondary CTA Label</label><input type="text" value="${esc(d.ctaSecondaryLabel)}" oninput="updateBlockData('${b.id}',{ctaSecondaryLabel:this.value})"></div>
      <div class="rp-field" style="display:flex;gap:8px;align-items:center;"><label style="margin:0;">Show Stats</label><input type="checkbox" ${d.showStats?'checked':''} onchange="updateBlockData('${b.id}',{showStats:this.checked})"></div>`;
    case 'features': return `
      <div class="rp-field"><label>Heading</label><input type="text" value="${esc(d.heading)}" oninput="updateBlockData('${b.id}',{heading:this.value})"></div>
      <div class="rp-field"><label>Subheading</label><textarea rows="2" oninput="updateBlockData('${b.id}',{subheading:this.value})">${esc(d.subheading)}</textarea></div>
      <div class="rp-field"><label>Layout</label><select onchange="updateBlockData('${b.id}',{layout:this.value})">${['grid3','grid2','horizontal'].map(v=>`<option value="${v}"${d.layout===v?' selected':''}>${v}</option>`).join('')}</select></div>
      <div class="label">Feature Cards</div>
      ${d.items.map((item,i)=>`<div class="mini-card"><div class="mini-card-hd"><span>Card ${i+1}</span><button class="btn btn-danger btn-icon btn-sm" onclick="featItemDel('${b.id}',${i})">✕</button></div><input type="text" value="${esc(item.icon)}" placeholder="Icon" oninput="featItemUpdate('${b.id}',${i},'icon',this.value)" style="margin-bottom:3px;"><input type="text" value="${esc(item.title)}" placeholder="Title" oninput="featItemUpdate('${b.id}',${i},'title',this.value)" style="margin-bottom:3px;"><textarea rows="2" placeholder="Description" oninput="featItemUpdate('${b.id}',${i},'desc',this.value)">${esc(item.desc)}</textarea></div>`).join('')}
      <button class="btn btn-ghost btn-sm" style="width:100%;" onclick="featItemAdd('${b.id}')">+ Add Card</button>`;
    case 'pricing': return `
      <div class="rp-field"><label>Heading</label><input type="text" value="${esc(d.heading)}" oninput="updateBlockData('${b.id}',{heading:this.value})"></div>
      <div class="rp-field"><label>Subheading</label><textarea rows="2" oninput="updateBlockData('${b.id}',{subheading:this.value})">${esc(d.subheading)}</textarea></div>
      <div class="label">Tiers</div>
      ${d.tiers.map((t,i)=>`<div class="mini-card"><div class="mini-card-hd"><span>Tier ${i+1}</span><div style="display:flex;gap:5px;align-items:center;"><label style="font-size:10px;color:var(--text2);">Featured</label><input type="checkbox" ${t.featured?'checked':''} onchange="priceTierUpdate('${b.id}',${i},'featured',this.checked)"><button class="btn btn-danger btn-icon btn-sm" onclick="priceTierDel('${b.id}',${i})">✕</button></div></div>
      <input type="text" value="${esc(t.name)}" placeholder="Name" oninput="priceTierUpdate('${b.id}',${i},'name',this.value)" style="margin-bottom:3px;">
      <div style="display:flex;gap:4px;margin-bottom:3px;"><input type="text" value="${esc(t.price)}" placeholder="$49" oninput="priceTierUpdate('${b.id}',${i},'price',this.value)" style="flex:1;"><input type="text" value="${esc(t.period)}" placeholder="/mo" oninput="priceTierUpdate('${b.id}',${i},'period',this.value)" style="flex:1;"></div>
      <textarea rows="3" placeholder="Features (one per line)" oninput="priceTierUpdate('${b.id}',${i},'features',this.value.split('\\n').filter(Boolean))">${(t.features||[]).join('\n')}</textarea>
      <input type="text" value="${esc(t.cta)}" placeholder="CTA label" oninput="priceTierUpdate('${b.id}',${i},'cta',this.value)" style="margin-top:3px;"></div>`).join('')}
      <button class="btn btn-ghost btn-sm" style="width:100%;" onclick="priceTierAdd('${b.id}')">+ Add Tier</button>`;
    case 'testimonials': return `
      <div class="rp-field"><label>Heading</label><input type="text" value="${esc(d.heading)}" oninput="updateBlockData('${b.id}',{heading:this.value})"></div>
      <div class="rp-field"><label>Subheading</label><textarea rows="2" oninput="updateBlockData('${b.id}',{subheading:this.value})">${esc(d.subheading)}</textarea></div>
      <div class="label">Reviews</div>
      ${d.items.map((item,i)=>`<div class="mini-card"><div class="mini-card-hd"><span>Review ${i+1}</span><button class="btn btn-danger btn-icon btn-sm" onclick="testItemDel('${b.id}',${i})">✕</button></div>
      <textarea rows="2" placeholder="Quote" oninput="testItemUpdate('${b.id}',${i},'quote',this.value)" style="margin-bottom:3px;">${esc(item.quote)}</textarea>
      <input type="text" value="${esc(item.author)}" placeholder="Author" oninput="testItemUpdate('${b.id}',${i},'author',this.value)" style="margin-bottom:3px;">
      <div style="display:flex;gap:4px;"><input type="text" value="${esc(item.role)}" placeholder="Role" oninput="testItemUpdate('${b.id}',${i},'role',this.value)" style="flex:1;"><input type="text" value="${esc(item.company)}" placeholder="Company" oninput="testItemUpdate('${b.id}',${i},'company',this.value)" style="flex:1;"></div></div>`).join('')}
      <button class="btn btn-ghost btn-sm" style="width:100%;" onclick="testItemAdd('${b.id}')">+ Add Review</button>`;
    case 'cta': return `
      <div class="rp-field"><label>Heading</label><textarea rows="2" oninput="updateBlockData('${b.id}',{heading:this.value})">${esc(d.heading)}</textarea></div>
      <div class="rp-field"><label>Subheading</label><textarea rows="2" oninput="updateBlockData('${b.id}',{subheading:this.value})">${esc(d.subheading)}</textarea></div>
      <div class="rp-field"><label>Primary CTA</label><input type="text" value="${esc(d.ctaPrimaryLabel)}" oninput="updateBlockData('${b.id}',{ctaPrimaryLabel:this.value})"></div>
      <div class="rp-field"><label>Secondary CTA</label><input type="text" value="${esc(d.ctaSecondaryLabel)}" oninput="updateBlockData('${b.id}',{ctaSecondaryLabel:this.value})"></div>
      <div class="rp-field"><label>Style</label><select onchange="updateBlockData('${b.id}',{style:this.value})">${['banner','card','full'].map(v=>`<option value="${v}"${d.style===v?' selected':''}>${v}</option>`).join('')}</select></div>`;
    case 'gallery': return `
      <div class="rp-field"><label>Heading</label><input type="text" value="${esc(d.heading)}" oninput="updateBlockData('${b.id}',{heading:this.value})"></div>
      <div class="rp-field"><label>Subheading</label><textarea rows="2" oninput="updateBlockData('${b.id}',{subheading:this.value})">${esc(d.subheading)}</textarea></div>
      <div class="label">Images</div>
      ${d.images.map((img,i)=>`<div class="mini-card"><div class="mini-card-hd"><span>Image ${i+1}</span><button class="btn btn-danger btn-icon btn-sm" onclick="galleryImgDel('${b.id}',${i})">✕</button></div>
      <input type="url" value="${esc(img.url)}" placeholder="Image URL" oninput="galleryImgUpdate('${b.id}',${i},'url',this.value)" style="margin-bottom:3px;">
      <input type="text" value="${esc(img.caption)}" placeholder="Caption" oninput="galleryImgUpdate('${b.id}',${i},'caption',this.value)"></div>`).join('')}
      <button class="btn btn-ghost btn-sm" style="width:100%;" onclick="galleryImgAdd('${b.id}')">+ Add Image</button>`;
    case 'widget': return `
      <div class="rp-field"><label>Heading</label><input type="text" value="${esc(d.heading)}" oninput="updateBlockData('${b.id}',{heading:this.value})"></div>
      <div class="rp-field"><label>Widget Type</label><select onchange="updateBlockData('${b.id}',{widgetType:this.value})">${['countdown','video','map','embed'].map(v=>`<option value="${v}"${d.widgetType===v?' selected':''}>${v}</option>`).join('')}</select></div>
      ${d.widgetType==='countdown'?`<div class="rp-field"><label>Target Date</label><input type="date" value="${esc(d.targetDate)}" oninput="updateBlockData('${b.id}',{targetDate:this.value})"></div>`:
      `<div class="rp-field"><label>Embed URL</label><input type="url" value="${esc(d.embedUrl)}" placeholder="https://..." oninput="updateBlockData('${b.id}',{embedUrl:this.value})"></div>`}`;
    case 'footer': return `
      <div class="rp-field"><label>Logo Text</label><input type="text" value="${esc(d.logo)}" oninput="updateBlockData('${b.id}',{logo:this.value})"></div>
      <div class="rp-field"><label>Tagline</label><textarea rows="2" oninput="updateBlockData('${b.id}',{tagline:this.value})">${esc(d.tagline)}</textarea></div>
      <div class="rp-field"><label>Copyright</label><input type="text" value="${esc(d.copyright)}" oninput="updateBlockData('${b.id}',{copyright:this.value})"></div>
      <div class="rp-field" style="display:flex;gap:8px;align-items:center;"><label style="margin:0;">Show Socials</label><input type="checkbox" ${d.showSocials?'checked':''} onchange="updateBlockData('${b.id}',{showSocials:this.checked})"></div>
      ${d.showSocials?`<div class="rp-field"><label>Twitter URL</label><input type="url" value="${esc(d.social.twitter)}" oninput="updateBlockData('${b.id}',{social:{...APP.project.blocks.find(b=>b.id==='${b.id}').data.social,twitter:this.value}})"></div>`:''}`;
    case 'leadform': return `
      <div class="rp-field"><label>Heading</label><input type="text" value="${esc(d.heading)}" oninput="updateBlockData('${b.id}',{heading:this.value})"></div>
      <div class="rp-field"><label>Subheading</label><textarea rows="2" oninput="updateBlockData('${b.id}',{subheading:this.value})">${esc(d.subheading)}</textarea></div>
      <div class="rp-field"><label>Submit Label</label><input type="text" value="${esc(d.submitLabel)}" oninput="updateBlockData('${b.id}',{submitLabel:this.value})"></div>
      <div class="rp-field"><label>Success Message</label><input type="text" value="${esc(d.successMessage)}" oninput="updateBlockData('${b.id}',{successMessage:this.value})"></div>
      <div class="rp-field"><label>Webhook URL</label><input type="url" value="${esc(d.webhookUrl)}" placeholder="https://..." oninput="updateBlockData('${b.id}',{webhookUrl:this.value})"></div>`;
    default: return '<p style="font-size:12px;color:var(--text2);padding:4px 0;">No content editor for this block type.</p>';
  }
}

function attachBlockEditorEvents(b) { /* events are inline */ }

// ── Inline block editor helpers (global scope for inline handlers) ─
window.navLinkUpdate = (id,i,k,v) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.links[i][k]=v; updateBlockData(id,{links:d.links}); };
window.navLinkDel    = (id,i) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.links.splice(i,1); updateBlockData(id,{links:d.links}); refreshRightPanel(); };
window.navLinkAdd    = (id) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.links.push({label:'Link',href:'#'}); updateBlockData(id,{links:d.links}); refreshRightPanel(); };
window.featItemUpdate = (id,i,k,v) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.items[i][k]=v; updateBlockData(id,{items:d.items}); };
window.featItemDel    = (id,i) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.items.splice(i,1); updateBlockData(id,{items:d.items}); refreshRightPanel(); };
window.featItemAdd    = (id) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.items.push({icon:'⭐',title:'New Feature',desc:'Description here.'}); updateBlockData(id,{items:d.items}); refreshRightPanel(); };
window.priceTierUpdate = (id,i,k,v) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.tiers[i][k]=v; updateBlockData(id,{tiers:d.tiers}); };
window.priceTierDel    = (id,i) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.tiers.splice(i,1); updateBlockData(id,{tiers:d.tiers}); refreshRightPanel(); };
window.priceTierAdd    = (id) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.tiers.push({name:'New Plan',price:'$0',period:'/mo',desc:'Description.',features:['Feature 1'],cta:'Get Started',featured:false}); updateBlockData(id,{tiers:d.tiers}); refreshRightPanel(); };
window.testItemUpdate  = (id,i,k,v) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.items[i][k]=v; updateBlockData(id,{items:d.items}); };
window.testItemDel     = (id,i) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.items.splice(i,1); updateBlockData(id,{items:d.items}); refreshRightPanel(); };
window.testItemAdd     = (id) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.items.push({quote:'Great product!',author:'New Person',role:'Founder',company:'Startup',rating:5}); updateBlockData(id,{items:d.items}); refreshRightPanel(); };
window.galleryImgUpdate = (id,i,k,v) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.images[i][k]=v; updateBlockData(id,{images:d.images}); };
window.galleryImgDel    = (id,i) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); d.images.splice(i,1); updateBlockData(id,{images:d.images}); refreshRightPanel(); };
window.galleryImgAdd    = (id) => { const d=clone(APP.project.blocks.find(b=>b.id===id).data); const n=d.images.length+1; d.images.push({url:`https://placehold.co/400x280/1a1a2e/ff6b35?text=Image+${n}`,alt:`Image ${n}`,caption:''}); updateBlockData(id,{images:d.images}); refreshRightPanel(); };
window.updateBlockData  = updateBlockData;
window.updateBlockStyle = updateBlockStyle;
window.deleteBlock      = deleteBlock;
window.toggleHide       = toggleHide;
window.moveBlock        = moveBlock;
window.toggleRpSection  = toggleRpSection;
window.refreshRightPanel = refreshRightPanel;
window.switchSidebarTab = switchSidebarTab;
window.el = el;
window.APP = APP;

// ── Sidebar tabs ───────────────────────────────────────────────────
function switchSidebarTab(tab) {
  APP.sidebarTab = tab;
  document.querySelectorAll('.stab').forEach(b=>b.classList.toggle('active', b.dataset.tab===tab));
  document.querySelectorAll('.tab-pane').forEach(p=>p.classList.toggle('active', p.dataset.tab===tab));
}

// ── Export HTML ────────────────────────────────────────────────────
function exportHTML() {
  const html = renderPage(APP.project);
  const blob = new Blob([html],{type:'text/html'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href=url; a.download=(APP.project.siteName||'site').replace(/[^a-z0-9]/gi,'-').toLowerCase()+'.html';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('HTML exported!', 'success');
}

// ── Full Preview ───────────────────────────────────────────────────
function openPreview() {
  const overlay = h('div',{cls:'modal-overlay',onclick:(e)=>{if(e.target===overlay)overlay.remove();}});
  const box = h('div',{cls:'modal-box full'});
  const header = h('div',{cls:'modal-header'},[
    h('h3',{txt:`Preview — ${APP.project.siteName}`}),
    h('div',{},{},)
  ]);
  const btns = h('div',{style:'display:flex;gap:8px;'});
  const exp = h('button',{cls:'btn btn-accent btn-sm',txt:'Export HTML',onclick:exportHTML});
  const cls = h('div',{cls:'modal-close',txt:'✕',onclick:()=>overlay.remove()});
  btns.appendChild(exp); btns.appendChild(cls);
  header.appendChild(btns);
  const iframe = h('iframe',{style:'width:100%;height:100%;border:none;',sandbox:'allow-scripts allow-same-origin',title:'preview'});
  box.appendChild(header); box.appendChild(iframe);
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  setTimeout(()=>{
    const doc=iframe.contentDocument;
    doc.open(); doc.write(renderPage(APP.project)); doc.close();
  },30);
}

// ── Share Modal ────────────────────────────────────────────────────
function openShare() {
  const tier = APP.session.tier;
  const overlay = h('div',{cls:'modal-overlay',onclick:(e)=>{if(e.target===overlay)overlay.remove();}});
  const box = h('div',{cls:'modal-box sm'});
  const header = h('div',{cls:'modal-header'},[h('h3',{txt:'Share Project'}),h('div',{cls:'modal-close',txt:'✕',onclick:()=>overlay.remove()})]);
  const body = h('div',{cls:'modal-body'});
  if (tier==='free'||tier==='basic') {
    body.innerHTML=`<div style="text-align:center;padding:20px 0;"><div style="font-size:36px;margin-bottom:12px;">🔒</div><p style="font-size:14px;font-weight:600;margin-bottom:8px;">Requires Pro or Agency</p><p style="font-size:13px;color:var(--text2);">Upgrade to share this project with real-time collaborators.</p></div>`;
  } else {
    const code = Array.from({length:8},()=>'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[Math.floor(Math.random()*36)]).join('');
    body.innerHTML=`<p style="font-size:13px;color:var(--text2);margin-bottom:16px;">Share this code with your team to collaborate in real time.</p>
    <div style="background:var(--bg3);border:1px solid var(--border2);border-radius:var(--r-md);padding:14px;text-align:center;margin-bottom:14px;">
      <div style="font-family:'Courier New',monospace;font-size:28px;font-weight:700;color:var(--accent);letter-spacing:4px;">${code}</div>
      <div style="font-size:12px;color:var(--text2);margin-top:6px;">Valid for 48 hours</div>
    </div>
    <button class="btn btn-ghost" style="width:100%;" onclick="navigator.clipboard.writeText('${code}').then(()=>window.toast('Code copied!','success'))">Copy Code</button>`;
  }
  box.appendChild(header); box.appendChild(body);
  overlay.appendChild(box);
  document.body.appendChild(overlay);
}
window.toast = toast;

// ── RENDER: Landing Page ──────────────────────────────────────────
function renderLanding() {
  const app = el('app');
  const plans = [
    {code:'SS26',tier:'free',name:'Free',price:'$0',period:'/mo',desc:'For personal projects.',features:['1 project','6 blocks','Basic themes','HTML export'],popular:false},
    {code:'SSBASIC',tier:'basic',name:'Basic',price:'$19',period:'/mo',desc:'For freelancers.',features:['3 projects','20 blocks','All themes','Share codes'],popular:false},
    {code:'SSPRO',tier:'pro',name:'Pro',price:'$49',period:'/mo',desc:'For growing businesses.',features:['10 projects','Unlimited blocks','Live collaboration','Priority support'],popular:true},
    {code:'SSAGENCY',tier:'agency',name:'Agency',price:'$149',period:'/mo',desc:'For agencies.',features:['Unlimited projects','Custom webhooks','White-label','SLA guarantee'],popular:false},
  ];
  const feats = [
    {icon:'⚡',title:'10 Block Types',desc:'Nav, Hero, Features, Pricing, Testimonials, CTA, Gallery, Widget, Footer, Lead Form — all production-ready.'},
    {icon:'🎨',title:'5 Pro Themes',desc:'Liquid Glass, Classy Bold, Neon Dark, Brutalist, Minimal Zen. Switch in seconds.'},
    {icon:'👥',title:'Live Collaboration',desc:'Real-time WebSocket collaboration for Pro & Agency plans.'},
    {icon:'🔧',title:'Per-Block Styling',desc:'Glass, solid, gradient backgrounds. Padding, radius, and alignment for every block.'},
    {icon:'📤',title:'HTML Export',desc:'Single standalone HTML file with all styles, fonts, and interactivity included.'},
    {icon:'↩',title:'Undo / Redo',desc:'Unlimited undo/redo history. Experiment freely and roll back any mistake.'},
  ];
  const faqs = [
    {q:'What is Supersuite?',a:'A professional visual website builder — Webflow-style. Compose pages from blocks, style with themes, collaborate in real time, and export clean HTML.'},
    {q:'How do access codes work?',a:'Each plan has a code. Enter it when you start. Your code controls project and block limits. Free: SS26 · Basic: SSBASIC · Pro: SSPRO · Agency: SSAGENCY.'},
    {q:'Is there a time limit on free sessions?',a:'No time limit. Work auto-saves every 30 seconds to your browser.'},
    {q:'Can I collaborate in real time?',a:'Yes — Pro and Agency plans. Share a code and teammates join your project via WebSocket.'},
    {q:'What does HTML export include?',a:'A single self-contained file with CSS, fonts, and block content. Countdown timers and forms are fully functional.'},
  ];

  app.innerHTML = '';
  const page = h('div',{cls:'lp'});
  page.innerHTML = `
  <header class="lp-nav">
    <div class="lp-nav-inner">
      <div class="lp-logo"><div class="lp-logo-mark">SS</div><div class="lp-logo-name">Supersuite</div><div class="lp-version">SSV26.1</div></div>
      <div class="lp-nav-links"><a href="#features">Features</a><a href="#pricing">Pricing</a><a href="#faq">FAQ</a></div>
      <button class="lp-nav-cta" id="lp-start-btn">Start Building</button>
    </div>
  </header>

  <section class="lp-hero">
    <div class="lp-orb" style="width:560px;height:560px;background:radial-gradient(circle,rgba(255,107,53,.12),transparent 70%);top:-120px;left:50%;transform:translateX(-50%);"></div>
    <div class="lp-orb" style="width:360px;height:360px;background:radial-gradient(circle,rgba(139,92,246,.1),transparent 70%);top:60px;right:-60px;"></div>
    <div class="hero-inner">
      <div class="hero-badge"><span class="hero-dot"></span>Now live — SSV26.1</div>
      <h1 class="hero-h1">Build <span class="hero-accent">production websites</span><br>without writing code</h1>
      <p class="hero-sub">Supersuite is a visual website builder with 10 block types, 5 pro themes, real-time collaboration, and one-click HTML export.</p>
      <div class="hero-ctas">
        <button class="hero-btn-primary" id="hero-start-btn">Start Building Free</button>
        <button class="hero-btn-ghost" onclick="document.getElementById('features').scrollIntoView({behavior:'smooth'})">Explore Features</button>
      </div>
      <div class="hero-stats">
        <div class="stat"><span class="stat-num">10</span><span class="stat-label">Block Types</span></div>
        <div class="stat-div"></div>
        <div class="stat"><span class="stat-num">5</span><span class="stat-label">Pro Themes</span></div>
        <div class="stat-div"></div>
        <div class="stat"><span class="stat-num">∞</span><span class="stat-label">Undo/Redo</span></div>
        <div class="stat-div"></div>
        <div class="stat"><span class="stat-num">1</span><span class="stat-label">Click Export</span></div>
      </div>
    </div>
  </section>

  <section class="lp-section" id="features"><div class="lp-inner">
    <div class="section-kicker">Features</div>
    <h2 class="section-h2">Everything a pro needs</h2>
    <p class="section-sub">10 blocks, 5 themes, live collab, undo/redo, and HTML export — all in one.</p>
    <div class="feat-grid">${feats.map(f=>`<div class="feat-card"><div class="feat-icon">${f.icon}</div><h3>${f.title}</h3><p>${f.desc}</p></div>`).join('')}</div>
  </div></section>

  <section class="lp-pricing" id="pricing"><div class="lp-inner">
    <div class="text-center" style="margin-bottom:44px;"><div class="section-kicker">Pricing</div><h2 class="section-h2">Simple, transparent pricing</h2><p class="section-sub center">Enter your access code to get started. No credit card required.</p></div>
    <div class="pricing-grid">${plans.map(p=>`
      <div class="plan-card${p.popular?' plan-featured':''}">
        ${p.popular?`<div class="plan-badge">Most Popular</div>`:''}
        <div class="plan-name">${p.name}</div>
        <div class="plan-price">${p.price}<span>${p.period}</span></div>
        <p class="plan-desc">${p.desc}</p>
        <div class="plan-code-row">Code: <span class="plan-code">${p.code}</span></div>
        <ul class="plan-features">${p.features.map(f=>`<li>${f}</li>`).join('')}</ul>
        <button class="plan-btn${p.popular?' plan-btn-featured':''}" data-code="${p.code}" data-plan="open">Use ${p.code}</button>
      </div>`).join('')}
    </div>
    <p style="text-align:center;margin-top:28px;font-size:12px;color:var(--text2);">Enter your access code on the next screen.</p>
  </div></section>

  <section class="lp-section" id="faq"><div class="lp-inner">
    <div class="section-kicker">FAQ</div>
    <h2 class="section-h2">Got questions?</h2>
    <div class="faq-list">${faqs.map((f,i)=>`
      <div class="faq-item">
        <button class="faq-q" data-faq="${i}">${f.q}<span class="faq-arrow">▾</span></button>
        <div class="faq-a" id="faq-a-${i}">${f.a}</div>
      </div>`).join('')}
    </div>
  </div></section>

  <footer class="lp-footer"><div class="lp-footer-inner">
    <div style="display:flex;align-items:center;gap:10px;"><div class="lp-logo-mark" style="width:26px;height:26px;font-size:10px;">SS</div><span style="font-size:13px;color:var(--text2);">Supersuite SSV26.1</span></div>
    <span style="font-size:13px;color:var(--text2);">Pure vanilla JS · No frameworks</span>
  </div></footer>`;

  app.appendChild(page);

  // FAQ accordion
  page.querySelectorAll('.faq-q').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const i = btn.dataset.faq;
      const ans = el('faq-a-'+i);
      const isOpen = ans.classList.contains('open');
      page.querySelectorAll('.faq-a').forEach(a=>a.classList.remove('open'));
      page.querySelectorAll('.faq-q').forEach(b=>b.classList.remove('open'));
      if (!isOpen) { ans.classList.add('open'); btn.classList.add('open'); }
    });
  });

  // Plan buttons
  page.querySelectorAll('[data-plan="open"]').forEach(btn=>{
    btn.addEventListener('click',()=>openLogin(btn.dataset.code));
  });
  el('lp-start-btn').addEventListener('click',()=>openLogin());
  el('hero-start-btn').addEventListener('click',()=>openLogin());
}

// ── Login Modal ────────────────────────────────────────────────────
function openLogin(prefillCode='') {
  const overlay = h('div',{cls:'modal-overlay'});
  const box = h('div',{cls:'modal-box md'});
  overlay.addEventListener('click',(e)=>{if(e.target===overlay)overlay.remove();});

  let tab = 'code';
  let codeVal = prefillCode;
  let nameVal = '';
  let joinVal = '';
  let err = '';

  function renderModal() {
    box.innerHTML = `
    <div class="modal-header">
      <div class="gate-logo"><div class="gate-mark">SS</div><div><div class="gate-name">Supersuite<small>SSV26.1 — Visual Builder</small></div></div></div>
      <div class="modal-close" id="gate-close">✕</div>
    </div>
    <div class="modal-body">
      <div class="gate-tabs">
        <button class="gate-tab${tab==='code'?' active':''}" data-tab="code">Enter Access Code</button>
        <button class="gate-tab${tab==='join'?' active':''}" data-tab="join">Join with Share Code</button>
      </div>
      <div class="rp-field"><label>Your Name</label><input type="text" id="gate-name" value="${esc(nameVal)}" placeholder="Alex Johnson" autocomplete="name"></div>
      ${tab==='code'?`
        <div class="rp-field"><label>Access Code</label><div style="display:flex;gap:7px;">
          <input type="text" id="gate-code" value="${esc(codeVal)}" placeholder="SS26 · SSBASIC · SSPRO · SSAGENCY" style="font-family:'Courier New',monospace;letter-spacing:.08em;flex:1;">
          <button class="btn btn-accent" id="gate-enter-btn">Enter</button>
        </div></div>
        <div class="gate-error" id="gate-err">${err}</div>
        <div class="gate-codes" style="margin-top:14px;">
          <div class="label">Available Codes</div>
          ${[['SS26','free','Free','1 project · 6 blocks'],['SSBASIC','basic','Basic','3 projects · 20 blocks'],['SSPRO','pro','Pro','10 projects · 100 blocks'],['SSAGENCY','agency','Agency','Unlimited']].map(([c,t,n,d])=>
            `<div class="gate-code-row" data-fill="${c}"><span class="code-pill">${c}</span><span class="tier-pill ${TIER_CLASS[t]}">${n}</span><span class="tier-limit">${d}</span></div>`).join('')}
        </div>
      `:`
        <div class="rp-field"><label>Share Code</label><div style="display:flex;gap:7px;">
          <input type="text" id="gate-join" value="${esc(joinVal)}" placeholder="8-character share code" style="font-family:'Courier New',monospace;letter-spacing:.1em;flex:1;">
          <button class="btn btn-accent" id="gate-join-btn">Join</button>
        </div></div>
        <div class="gate-error" id="gate-err">${err}</div>
        <p style="font-size:12px;color:var(--text2);margin-top:10px;line-height:1.6;">Get a share code from a collaborator to open their project.</p>
      `}
    </div>`;

    el('gate-close').onclick = ()=>overlay.remove();
    box.querySelectorAll('.gate-tab').forEach(b=>b.addEventListener('click',()=>{tab=b.dataset.tab;err='';renderModal();}));

    const nameInput = el('gate-name');
    nameInput.addEventListener('input',()=>nameVal=nameInput.value);
    nameInput.addEventListener('keydown',(e)=>{if(e.key==='Enter')attempt();});

    if (tab==='code') {
      const codeInput = el('gate-code');
      codeInput.addEventListener('input',()=>{codeVal=codeInput.value.toUpperCase();el('gate-err').textContent='';});
      codeInput.addEventListener('keydown',(e)=>{if(e.key==='Enter')attempt();});
      el('gate-enter-btn').addEventListener('click',attempt);
      box.querySelectorAll('[data-fill]').forEach(row=>row.addEventListener('click',()=>{codeVal=row.dataset.fill;renderModal();setTimeout(()=>el('gate-name').focus(),50);}));
    } else {
      const joinInput = el('gate-join');
      joinInput.addEventListener('input',()=>{joinVal=joinInput.value.toUpperCase();el('gate-err').textContent='';});
      joinInput.addEventListener('keydown',(e)=>{if(e.key==='Enter')attempt();});
      el('gate-join-btn').addEventListener('click',attempt);
    }
    setTimeout(()=>(el('gate-name')?.focus()),50);
  }

  function attempt() {
    const nameI = el('gate-name'); if (nameI) nameVal=nameI.value.trim();
    if (!nameVal) { el('gate-err').textContent='Please enter your name.'; return; }
    if (tab==='code') {
      const codeI = el('gate-code'); if (codeI) codeVal=codeI.value.trim().toUpperCase();
      const tier = ACCESS_CODES[codeVal];
      if (!tier) { el('gate-err').textContent='Invalid code. Try: SS26, SSBASIC, SSPRO, or SSAGENCY'; return; }
      overlay.remove();
      startSession(codeVal, tier, nameVal);
    } else {
      const joinI = el('gate-join'); if (joinI) joinVal=joinI.value.trim().toUpperCase();
      if (!joinVal) { el('gate-err').textContent='Enter a share code.'; return; }
      overlay.remove();
      startSession('SSPRO', 'pro', nameVal, joinVal);
    }
  }

  renderModal();
  box.classList.add('animate-slideup');
  overlay.appendChild(box);
  document.body.appendChild(overlay);
}

// ── Start Builder Session ─────────────────────────────────────────
function startSession(code, tier, name, joinCode='') {
  const sessionId = Math.random().toString(36).slice(2)+Date.now().toString(36);
  APP.session = { sessionId, name, tier, code };
  APP.history = []; APP.future = []; APP.selectedId = null;
  store.set('ss-session', APP.session);

  // Load saved project or create new
  const saved = store.get('ss-project-'+sessionId);
  APP.project = saved || createProject('My Awesome Site');
  store.set('ss-project-'+sessionId, APP.project);
  APP.screen = 'builder';
  renderBuilder();
}

// ── RENDER: Builder ────────────────────────────────────────────────
function renderBuilder() {
  const app = el('app');
  app.innerHTML = '';

  const builder = h('div',{cls:'builder'});
  builder.innerHTML = `
  <!-- TOP NAV -->
  <div class="top-nav">
    <div class="nav-l">
      <div class="nav-logo"><div class="nav-mark">SS</div><div class="nav-name">Supersuite</div></div>
      <input class="nav-site-input" id="site-name-input" type="text" value="${esc(APP.project.siteName)}" title="Site name">
      <span class="tier-tag ${TIER_CLASS[APP.session.tier]}">${APP.session.tier.toUpperCase()}</span>
    </div>
    <div class="nav-c">
      <div class="device-sw">
        <button class="dev-btn active" data-dev="desktop">D</button>
        <button class="dev-btn" data-dev="tablet">T</button>
        <button class="dev-btn" data-dev="mobile">M</button>
      </div>
    </div>
    <div class="nav-r">
      <button class="hist-btn" id="undo-btn" disabled title="Undo">↩</button>
      <button class="hist-btn" id="redo-btn" disabled title="Redo">↪</button>
      <button class="btn-preview-nav" id="preview-btn">Preview</button>
      <button class="btn-share" id="share-btn">Share</button>
      <button class="btn-export" id="export-btn">Export HTML</button>
      <button class="hist-btn" id="exit-btn" title="Exit to landing">✕</button>
    </div>
  </div>

  <!-- BUILDER LAYOUT -->
  <div class="builder-layout">
    <!-- SIDEBAR -->
    <div class="sidebar">
      <div class="sidebar-tabs">
        ${[['blocks','+','Blocks'],['themes','◈','Themes'],['styles','◑','Styles'],['layers','≡','Layers']].map(([t,i,l])=>`<button class="stab${t==='blocks'?' active':''}" data-tab="${t}"><span class="si">${i}</span>${l}</button>`).join('')}
      </div>

      <!-- Blocks tab -->
      <div class="tab-pane active" data-tab="blocks">
        <div class="tab-head"><h3>Add Block</h3><p id="block-count-label"></p></div>
        <div class="block-lib" id="block-lib"></div>
      </div>

      <!-- Themes tab -->
      <div class="tab-pane" data-tab="themes">
        <div class="tab-head"><h3>Theme</h3><p>Switch the design system</p></div>
        <div class="theme-list" id="theme-list"></div>
      </div>

      <!-- Styles tab -->
      <div class="tab-pane" data-tab="styles">
        <div class="tab-head"><h3>Global Styles</h3><p>Applied to all blocks</p></div>
        <div class="styles-pane" id="styles-pane"></div>
      </div>

      <!-- Layers tab -->
      <div class="tab-pane" data-tab="layers">
        <div class="tab-head"><h3>Layers</h3><p id="layers-count"></p></div>
        <div class="layers-list" id="layers-list"></div>
      </div>
    </div>

    <!-- CANVAS -->
    <div class="canvas-area">
      <div class="canvas-toolbar">
        <div class="canvas-info"><span id="canvas-dev-label">desktop · 1200px</span><span id="canvas-editing" class="editing"></span></div>
        <div class="zoom-row">
          <button class="btn btn-ghost btn-icon btn-sm" id="zoom-out">−</button>
          <span class="zoom-val" id="zoom-val">100%</span>
          <button class="btn btn-ghost btn-icon btn-sm" id="zoom-in">+</button>
          <button class="btn btn-ghost btn-sm" id="zoom-reset" style="font-size:10px;">Reset</button>
        </div>
      </div>
      <div class="canvas-scroll" id="canvas-scroll">
        <div class="canvas-wrapper" id="canvas-wrapper">
          <iframe class="preview-iframe" id="preview-iframe" sandbox="allow-scripts allow-same-origin" title="preview" style="width:1200px;height:max(600px,85vh);min-height:600px;"></iframe>
        </div>
      </div>
    </div>

    <!-- RIGHT PANEL -->
    <div class="right-panel">
      <div class="rp-header"><h3 id="rp-title">Properties</h3><button class="btn btn-ghost btn-icon btn-sm" id="rp-deselect" style="display:none;" title="Deselect">✕</button></div>
      <div class="rp-body" id="rp-body">
        <div class="rp-empty"><div class="rp-empty-icon">◑</div><p>Select a block from the Layers panel to edit its content and style.</p><button class="btn btn-ghost btn-sm" onclick="switchSidebarTab('layers')" style="margin-top:8px;">Open Layers</button></div>
      </div>
    </div>
  </div>

  <!-- STATUS BAR -->
  <div class="status-bar">
    <div class="status-dot ok" id="status-dot"></div>
    <span id="status-saved">Saved</span>
    <span>·</span>
    <span id="status-blocks"></span>
    <button class="status-save-btn" id="status-save-btn" style="margin-left:auto;">Save Now</button>
  </div>`;

  app.appendChild(builder);

  // Wire up block library
  const blockLib = el('block-lib');
  BLOCK_DEFS.forEach(def=>{
    const card = h('div',{cls:'block-card',onclick:()=>addBlock(def.type)});
    card.innerHTML=`<div class="block-preview">${def.preview}</div><div class="block-label"><div><strong>${def.label}</strong><small>${def.desc}</small></div></div>`;
    blockLib.appendChild(card);
  });

  // Wire up theme list
  const themeList = el('theme-list');
  THEMES.forEach(theme=>{
    const card = h('div',{cls:'theme-card'+(APP.project.globalStyles.theme===theme.id?' active':'')});
    card.innerHTML=`<div class="theme-preview" style="background:linear-gradient(135deg,${theme.colors[0]},${theme.colors[1]});">
      ${theme.colors.map(c=>`<div class="theme-swatch" style="background:${c};"></div>`).join('')}
      <span class="theme-preview-name">${theme.name}</span>
      <div class="theme-check">✓</div>
    </div>
    <div class="theme-info"><strong>${theme.name}</strong><small>${theme.desc}</small></div>`;
    card.addEventListener('click',()=>{
      updateGS({theme:theme.id});
      themeList.querySelectorAll('.theme-card').forEach(c=>c.classList.toggle('active',c===card));
      toast(`Theme: ${theme.name}`, 'success');
    });
    themeList.appendChild(card);
  });

  // Wire up global styles pane
  buildStylesPane();

  // Sidebar tabs
  builder.querySelectorAll('.stab').forEach(btn=>{
    btn.addEventListener('click',()=>switchSidebarTab(btn.dataset.tab));
  });

  // Device switcher
  builder.querySelectorAll('.dev-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      APP.device = btn.dataset.dev;
      builder.querySelectorAll('.dev-btn').forEach(b=>b.classList.toggle('active',b===btn));
      const w = DEVICE_WIDTHS[APP.device];
      const iframe = el('preview-iframe');
      if (iframe) iframe.style.width = w+'px';
      el('canvas-dev-label').textContent = `${APP.device} · ${w}px`;
    });
  });

  // Zoom
  el('zoom-out').onclick = ()=>setZoom(Math.max(25,APP.zoom-10));
  el('zoom-in').onclick  = ()=>setZoom(Math.min(150,APP.zoom+10));
  el('zoom-reset').onclick = ()=>setZoom(100);

  // History
  el('undo-btn').onclick = undo;
  el('redo-btn').onclick = redo;

  // Site name
  el('site-name-input').addEventListener('blur',(e)=>{ pushState({...APP.project,siteName:e.target.value}); });
  el('site-name-input').addEventListener('keydown',(e)=>{ if(e.key==='Enter') e.target.blur(); });

  // Nav actions
  el('preview-btn').onclick = openPreview;
  el('share-btn').onclick   = openShare;
  el('export-btn').onclick  = exportHTML;
  el('exit-btn').onclick    = ()=>{ store.del('ss-session'); APP.screen='landing'; APP.session=null; APP.project=null; renderLanding(); };

  // Right panel deselect
  el('rp-deselect').onclick = ()=>{ APP.selectedId=null; el('rp-deselect').style.display='none'; refreshRightPanel(); el('canvas-editing').textContent=''; };

  // Status save
  el('status-save-btn').onclick = ()=>{ if(APP.project&&APP.session){ store.set('ss-project-'+APP.session.sessionId,APP.project); el('status-saved').textContent='Saved'; toast('Saved!','success'); } };

  // Keyboard shortcuts
  document.onkeydown = (e)=>{
    if ((e.ctrlKey||e.metaKey)&&e.key==='z'&&!e.shiftKey) { e.preventDefault(); undo(); }
    if ((e.ctrlKey||e.metaKey)&&(e.key==='y'||(e.key==='z'&&e.shiftKey))) { e.preventDefault(); redo(); }
  };

  // Auto-save every 30s
  if (window._autoSave) clearInterval(window._autoSave);
  window._autoSave = setInterval(()=>{
    if (APP.project&&APP.session) { store.set('ss-project-'+APP.session.sessionId,APP.project); el('status-saved').textContent='Auto-saved'; }
  }, 30000);

  // Initial render
  refreshCanvas();
  refreshLayers();
  refreshStatus();
  refreshRightPanel();

  // Update counters
  updateBlockCount();
}

function setZoom(z) {
  APP.zoom=z;
  el('zoom-val').textContent=z+'%';
  const wrapper = el('canvas-wrapper');
  if (wrapper) wrapper.style.transform=`scale(${z/100})`;
}

function updateBlockCount() {
  const lbl = el('block-count-label');
  const cnt = el('layers-count');
  if (!APP.project) return;
  const lim = TIER_LIMITS[APP.session.tier].blocks;
  if (lbl) lbl.textContent=`${APP.project.blocks.length} / ${lim} blocks used`;
  if (cnt) cnt.textContent=`${APP.project.blocks.length} blocks`;
}

function buildStylesPane() {
  const pane = el('styles-pane');
  if (!pane||!APP.project) return;
  const gs = APP.project.globalStyles;
  pane.innerHTML=`
  <div class="style-section">
    <h4>Typography</h4>
    <div class="style-row"><label>Heading</label>
      <select style="flex:1;" onchange="updateGS({fontHeading:this.value})">
        ${['Syne','DM Sans','Space Grotesk','Playfair Display','Raleway'].map(f=>`<option${gs.fontHeading===f?' selected':''}>${f}</option>`).join('')}
      </select></div>
    <div class="style-row"><label>Body</label>
      <select style="flex:1;" onchange="updateGS({fontBody:this.value})">
        ${['DM Sans','Syne','Space Grotesk','Raleway'].map(f=>`<option${gs.fontBody===f?' selected':''}>${f}</option>`).join('')}
      </select></div>
  </div>
  <div class="style-section">
    <h4>Colors</h4>
    ${[['colorPrimary','Primary'],['colorSecondary','Secondary'],['colorBg','Background'],['colorText','Text']].map(([k,l])=>`
    <div class="style-row"><label>${l}</label>
      <div class="color-wrap">
        <input type="color" value="${gs[k]||'#000000'}" oninput="updateGS({${k}:this.value})">
        <input type="text" value="${gs[k]||'#000000'}" class="color-hex" oninput="updateGS({${k}:this.value})">
      </div></div>`).join('')}
  </div>
  <div class="style-section">
    <h4>Layout</h4>
    <div class="style-row"><label>Corners</label>
      <select style="flex:1;" onchange="updateGS({borderRadius:this.value})">
        ${['sharp','soft','round'].map(v=>`<option value="${v}"${gs.borderRadius===v?' selected':''}>${v.charAt(0).toUpperCase()+v.slice(1)}</option>`).join('')}
      </select></div>
    <div class="style-row"><label>Spacing</label>
      <select style="flex:1;" onchange="updateGS({spacing:this.value})">
        ${['compact','normal','spacious'].map(v=>`<option value="${v}"${gs.spacing===v?' selected':''}>${v.charAt(0).toUpperCase()+v.slice(1)}</option>`).join('')}
      </select></div>
  </div>`;
}
window.updateGS = updateGS;
window.buildStylesPane = buildStylesPane;

// Override updateGS to also refresh styles pane
const _updateGS = updateGS;
window.updateGS = function(gs) {
  _updateGS(gs);
  buildStylesPane();
  const tl = el('theme-list');
  if (tl && APP.project) {
    const tid = APP.project.globalStyles.theme;
    tl.querySelectorAll('.theme-card').forEach((c,i)=>c.classList.toggle('active',THEMES[i].id===tid));
  }
};
updateGS = window.updateGS;

// ── Init ───────────────────────────────────────────────────────────
(function init() {
  // Check for existing session
  const saved = store.get('ss-session');
  if (saved) {
    APP.session = saved;
    const proj = store.get('ss-project-'+saved.sessionId);
    if (proj) {
      APP.project = proj;
      APP.screen = 'builder';
      renderBuilder();
      return;
    }
  }
  renderLanding();
})();
